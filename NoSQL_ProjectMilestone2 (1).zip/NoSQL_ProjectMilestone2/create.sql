--TABLE 1

-- Table: public.company

-- DROP TABLE IF EXISTS public.company;

CREATE TABLE IF NOT EXISTS public.company
(
    company_name character varying(100) COLLATE pg_catalog."default",
    company_id character varying(10) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT company_pkey PRIMARY KEY (company_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.company
    OWNER to postgres;
-------------------------------------------------------------------
--TABLE 2
-- Table: public.assets_earning_investments

-- DROP TABLE IF EXISTS public.assets_earning_investments;

CREATE TABLE IF NOT EXISTS public.assets_earning_investments
(
    company_id character varying(20) COLLATE pg_catalog."default",
    year_reported integer,
    asset character varying(100) COLLATE pg_catalog."default",
    sub_asset character varying(100) COLLATE pg_catalog."default",
    asset_value double precision,
    earnings_value double precision,
    earnings_record_number integer NOT NULL DEFAULT nextval('assets_earning_investments_earnings_record_number_seq'::regclass),
    CONSTRAINT assets_earning_investments_pkey PRIMARY KEY (earnings_record_number),
    CONSTRAINT assets_earning_investments_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.assets_earning_investments
    OWNER to postgres;
	
	
-----------------------------------------------------------------------------------
--TABLE 3.
-- Table: public.cost_per_unit

-- DROP TABLE IF EXISTS public.cost_per_unit;

CREATE TABLE IF NOT EXISTS public.cost_per_unit
(
    state_name character varying(100) COLLATE pg_catalog."default",
    city character varying(100) COLLATE pg_catalog."default",
    year_reported integer,
    jan double precision,
    feb double precision,
    march double precision,
    apr double precision,
    may double precision,
    jun double precision,
    jul double precision,
    aug double precision,
    sept double precision,
    oct double precision,
    nov double precision,
    decemeber double precision,
    state_id integer
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.cost_per_unit
    OWNER to postgres;
------------------------------------------------------------------------
--TABLE 4.
-- Table: public.customer_sales

-- DROP TABLE IF EXISTS public.customer_sales;

CREATE TABLE IF NOT EXISTS public.customer_sales
(
    utility_name character varying(100) COLLATE pg_catalog."default",
    company_id character varying(20) COLLATE pg_catalog."default",
    year_reported integer,
    customer_id integer NOT NULL,
    customer_name character varying(100) COLLATE pg_catalog."default",
    customers double precision,
    sales double precision,
    revenues double precision,
    CONSTRAINT customer_sales_pkey PRIMARY KEY (customer_id),
    CONSTRAINT customer_sales_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.customer_sales
    OWNER to postgres;
----------------------------------------------------------------------------
--TABLE 5.
-- Table: public.emission_region

-- DROP TABLE IF EXISTS public.emission_region;

CREATE TABLE IF NOT EXISTS public.emission_region
(
    reported_year integer,
    census_division_and_state character varying(30) COLLATE pg_catalog."default",
    carbon_dioxide_co2_thousand_metric_tons double precision,
    sulfur_dioxide_so2_thousand_metric_tons double precision,
    nitrogen_oxides_nox_thousand_metric_tons double precision,
    generation_thousand_megawatthours double precision,
    kilograms_of_co2_per_megawatthour_of_generation double precision,
    grams_of_so2_per_megawatthour_of_generation double precision,
    grams_of_nox_per_megawatthour_of_generation double precision
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.emission_region
    OWNER to postgres;
--------------------------------------------------------------------------------
--TABLE6.
-- Table: public.employees

-- DROP TABLE IF EXISTS public.employees;

CREATE TABLE IF NOT EXISTS public.employees
(
    parent_company_name character varying(100) COLLATE pg_catalog."default",
    company_name character varying(100) COLLATE pg_catalog."default",
    company_id character varying(10) COLLATE pg_catalog."default",
    year_reported integer,
    technology character varying(100) COLLATE pg_catalog."default",
    number_of_employees integer,
    CONSTRAINT employees_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT employees_count CHECK (number_of_employees > 0)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.employees
    OWNER to postgres;
------------------------------------------------------------------
--TABLE 7. 
-- Table: public.housing_units_income

-- DROP TABLE IF EXISTS public.housing_units_income;

CREATE TABLE IF NOT EXISTS public.housing_units_income
(
    company_id character varying(20) COLLATE pg_catalog."default",
    year_reported integer,
    area character varying(20) COLLATE pg_catalog."default",
    ownership character varying(20) COLLATE pg_catalog."default",
    housing_units double precision,
    income double precision,
    community_id integer NOT NULL,
    CONSTRAINT housing_units_income_pkey PRIMARY KEY (community_id),
    CONSTRAINT housing_units_income_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.housing_units_income
    OWNER to postgres;
-------------------------------------------------------------------
--TABLE 8.
-- Table: public.market_capitilization

-- DROP TABLE IF EXISTS public.market_capitilization;

CREATE TABLE IF NOT EXISTS public.market_capitilization
(
    ticker_tracker integer NOT NULL,
    company_id character varying(20) COLLATE pg_catalog."default",
    year_established integer,
    market_capitalization_in_billions integer,
    ownership character varying(20) COLLATE pg_catalog."default",
    indices character varying(100) COLLATE pg_catalog."default",
    city_name character varying(50) COLLATE pg_catalog."default",
    state_name character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT market_capitilization_pkey PRIMARY KEY (ticker_tracker),
    CONSTRAINT market_capitilization_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.market_capitilization
    OWNER to postgres;
-----------------------------------------------------------------------
--TABLE 9.
-- Table: public.utility_state_map

-- DROP TABLE IF EXISTS public.utility_state_map;

CREATE TABLE IF NOT EXISTS public.utility_state_map
(
    utility_name character varying(100) COLLATE pg_catalog."default",
    company_id character varying(10) COLLATE pg_catalog."default",
    year_reported integer,
    state_name character varying(20) COLLATE pg_catalog."default",
    state_abbr character varying(5) COLLATE pg_catalog."default",
    capacity_owned_in_state double precision,
    mwh_sales_in_state double precision,
    CONSTRAINT utility_state_map_company_id_fkey FOREIGN KEY (company_id)
        REFERENCES public.company (company_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.utility_state_map
    OWNER to postgres;