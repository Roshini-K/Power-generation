step1: use create.sql to create tables.
step2: right click on the table to import the data from .csv file
step3: write a select query to check if the data has been imported or not. if there's any error, the logs can be checked in the process section in pgadmin
step4: the 8 queries are mentioned in queries_for_phase_2.sql. each query can be runn seperately.
step5: to run UI, run the app.py and we can create tables using create.sql and import data from each csv files. the name of the table matches with the name of the .csv files
step6: import the following packages:
import psycopg2
import psycopg2.extras
import matplotlib.pyplot as plt
import matplotlib
import base64
import io

folders/files:
1. phase2 tables: contains all .csv data files
2. phase2_backup_files: contains all .dat data files
3. website1: all the files to run UI on local host
4. create.sql: create tables
5. dmql queries phase2.docx: contains all the 9 queries, their output and their screenshots
6. dmql queries phase2.sql: contains all 9 sql queries
7. demo video: recording of the project 
8. Milestone 2: final project report
