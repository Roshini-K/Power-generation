--queries for phase 2

--created a new table 
create table market_capitilization1(
ticker_tracker int primary key,
company_id varchar(20),
year_established int,
locations varchar(100),
market_capitalization_in_billions int,
ownership varchar(20),
indices varchar(100),
foreign key (company_id) references company(company_id)
);

--created a new attribute as state_id in cost_per_unit
alter table cost_per_unit add column state_id INT;

--created a new table employees
create table employees(
parent_company_name varchar(100),
company_name varchar(100),
company_id varchar(10),
year_reported int,
technology varchar(100),
number_of_employees int,
foreign key company_id references company(company_id));
	
	
--queries
--1. from utility_state_map, if the mwh_sales_in_state==0, means there is no sales by a company in that specific area
delete from utility_state_map where mwh_sales_in_state='0';
select * from utility_state_map where mwh_sales_in_state='0';

--2.joined 2 tables emissions_region_2021 and emissions_region_2022 as emissio_region
create table emission_region1 as
select * from emissions_region_2021
union all
select * from emissions_region_2022;

select * from emission_region;

--3.delete the rows in customer_sales where sales=0 when customers>1
delete from customer_sales where customers>1 and sales is null;


create table costs1 as select * from cost_per_unit;
--4.fill the NULL values with it's row avg using a function
CREATE OR REPLACE FUNCTION fill_null_with_row_avg()
RETURNS VOID AS $$
DECLARE
    row_record RECORD;
    row_avg NUMERIC;
BEGIN
    FOR row_record IN SELECT * FROM cost_per_unit LOOP
        -- Calculate the average for the current row excluding NULLs
        row_avg := ( SELECT AVG(v) FROM (VALUES
                (row_record.jan), (row_record.feb),(row_record.march),(row_record.apr),
                (row_record.may), (row_record.jun),(row_record.jul),(row_record.aug),
                (row_record.sept),(row_record.oct),(row_record.nov),(row_record.decemeber)
            ) AS t(v) WHERE t.v IS NOT NULL        );
        -- Update the row if necessary
        IF row_record.jan IS NULL OR row_record.feb IS NULL OR row_record.march IS NULL OR
           row_record.apr IS NULL OR row_record.may IS NULL OR row_record.jun IS NULL OR
           row_record.jul IS NULL OR row_record.aug IS NULL OR row_record.sept IS NULL OR
           row_record.oct IS NULL OR row_record.nov IS NULL OR row_record.decemeber IS NULL THEN
            UPDATE cost_per_unit SET
                jan = COALESCE(row_record.jan, row_avg),feb = COALESCE(row_record.feb, row_avg),march = COALESCE(row_record.march, row_avg),
                apr = COALESCE(row_record.apr, row_avg),may = COALESCE(row_record.may, row_avg),jun = COALESCE(row_record.jun, row_avg),
                jul = COALESCE(row_record.jul, row_avg),aug = COALESCE(row_record.aug, row_avg),sept = COALESCE(row_record.sept, row_avg),
                oct = COALESCE(row_record.oct, row_avg),nov = COALESCE(row_record.nov, row_avg),decemeber = COALESCE(row_record.decemeber, row_avg)
            WHERE state_name=row_record.state_name and city=row_record.city and year_reported=row_record.year_reported and state_id=row_record.state_id;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;
SELECT fill_null_with_row_avg();

--after filling
select * from cost_per_unit;


--5.in employees table, when the admin inserts the data into the table, constraint checks can be done
ALTER TABLE employees ADD CONSTRAINT employees_count CHECK (number_of_employees>0);

--6.split a column into 2 for better readability
-- Step 1: Add columns
ALTER TABLE market_capitilization
ADD COLUMN state_name varchar(50),
ADD COLUMN city varchar(50);

-- Step 2: Populate new columns
UPDATE market_capitilization
SET state_name = SPLIT_PART(locations, ',', 1),
    city = SPLIT_PART(locations, ',', 2);

-- Step 3: Drop the original column (optional)
ALTER TABLE market_capitilization DROP COLUMN locations;

--rename
alter table market_capitilization rename column state_name to city_name;
alter table market_capitilization rename city to state_name;
select * from market_capitilization;

--7. find the state-wise market capitilization using groupby
select state_name, round(avg(market_capitalization_in_billions),3) 
from market_capitilization
group by(state_name)
order by avg(market_capitalization_in_billions) desc;

--8.in which year & which company did the earnings_value was high. provide the sub_asset name also
select assets_earning_investments.year_reported, assets_earning_investments.sub_asset, company.company_name 
from company, assets_earning_investments
where company.company_id=(
	select assets_earning_investments.company_id from assets_earning_investments
	where assets_earning_investments.earnings_value=(
		select max(assets_earning_investments.earnings_value)
		from assets_earning_investments)
	limit 1)
AND assets_earning_investments.company_id = company.company_id
LIMIT 1


--optimized 8th query
SELECT ae.year_reported, ae.sub_asset, c.company_name 
FROM company c
JOIN assets_earning_investments ae ON c.company_id = ae.company_id
WHERE ae.company_id = (
    SELECT ae2.company_id
    FROM assets_earning_investments ae2
    WHERE ae2.earnings_value = (
        SELECT MAX(earnings_value)
        FROM assets_earning_investments
    )
    LIMIT 1
)
LIMIT 1;

--9th query
select company_name, year_reported,area,ownership,housing_units,income from company,housing_units_income 
where company.company_id=housing_units_income.company_id;

--optimized 9th query:
SELECT c.company_name, h.year_reported, h.area, h.ownership, h.housing_units, h.income
FROM company c
JOIN housing_units_income h ON c.company_id = h.company_id;



------------------------
select company_name from company where company_id in 
(select company_id from market_capitilization where state_name=' Ohio');

select * from market_capitilization;

select count(*) from customer_sales where year_reported=2020; 

select * from company;
select company_name,year_reported,asset,sub_asset,asset_value,earnings_value,earnings_record_number 
from company,assets_earning_investments where company_name='AEP Generating Co.';
select * from housing_units_income;
select company_name, year_reported,area,ownership,housing_units,income from company,housing_units_income 
where company.company_id=housing_units_income.company_id;