from flask import Flask, render_template, request
import psycopg2
import psycopg2.extras
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
import base64
import io

app = Flask(__name__)

def db_connection():
    conn = psycopg2.connect(database="power_generation", host="localhost", user="postgres", password="postgres")
    return conn

@app.route('/', methods=['GET', 'POST'])
def index():
    conn = db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute("SELECT DISTINCT state_name FROM market_capitilization")  # Assuming the table name is correct
    states = cur.fetchall()

    records = []
    state_name = None
    if request.method == 'POST':
        state_name = request.form.get('stateName')  # Using .get to avoid KeyError if 'stateName' isn't provided
        if state_name:  # Ensure state_name is not None or empty
            cur.execute("SELECT company_name FROM company WHERE company_id IN (SELECT company_id FROM market_capitilization WHERE state_name = %s)", (state_name,))
            records = cur.fetchall()

    cur.close()
    conn.close()
    return render_template("index.html", states=states, records=records, state_name=state_name)

@app.route('/about', methods=['GET', 'POST'])
def about():
    conn = db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    customer_records = []
    selected_year = None

    if request.method == 'POST':
        selected_year = request.form.get('selectedYear')
        if selected_year:
            cur.execute(
                "SELECT utility_name, customer_name, customers, sales, revenues FROM customer_sales WHERE year_reported = %s",
                (selected_year,)
            )
            customer_records = cur.fetchall()

    cur.close()
    conn.close()

    return render_template("about.html", customer_records=customer_records, selected_year=selected_year)


def plot_pollutants(data):
    # Extract the data for plotting
    pollutants = ['carbon_dioxide_co2_thousand_metric_tons', 'sulfur_dioxide_so2_thousand_metric_tons', 'nitrogen_oxides_nox_thousand_metric_tons']
    values = {2021: [], 2022: []}

    for entry in data:
        values[entry['reported_year']].extend([entry['carbon_dioxide_co2_thousand_metric_tons'], entry['sulfur_dioxide_so2_thousand_metric_tons'], entry['nitrogen_oxides_nox_thousand_metric_tons']])

    # Plotting
    fig, ax = plt.subplots(figsize=(15, 6))
    bar_width = 0.35
    index = range(len(pollutants))

    bar1 = ax.bar(index, values[2021], bar_width, label='2021')
    bar2 = ax.bar([i + bar_width for i in index], values[2022], bar_width, label='2022')

    ax.set_xlabel('Pollutants')
    ax.set_ylabel('Emissions (in Thousand Metric Tons)')
    ax.set_title('Emissions by Pollutants and Year')
    ax.set_xticks([r + bar_width / 2 for r in index])
    ax.set_xticklabels(pollutants)
    ax.legend()

    plt.tight_layout()

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()
    return base64.b64encode(img.getvalue()).decode('utf-8')

@app.route('/emissionsrate', methods=['GET', 'POST'])
def emissionsrate():
    conn = db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute("SELECT DISTINCT census_division_and_state FROM emission_region")  # Ensure this is the correct table name
    places = cur.fetchall()

    selected_place = None
    graph = None

    if request.method == 'POST':
        selected_place = request.form.get('place')

        if selected_place:
            cur.execute(
                "SELECT * FROM emission_region WHERE census_division_and_state = %s AND reported_year IN (2021, 2022)",(selected_place,))
            data = cur.fetchall()
            graph = plot_pollutants(data)

    cur.close()
    conn.close()
    return render_template("emissionsrate.html", places=places, graph=graph,selected_place=selected_place)

@app.route('/assets', methods=['GET', 'POST'])
def assets():
    conn = db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    
    # Query to get all company names for the dropdown
    cur.execute("SELECT company_name FROM company")
    companies = cur.fetchall()

    asset_details = []
    selected_company = None

    if request.method == 'POST':
        selected_company = request.form.get('companyName')

        # Query to get the assets and earnings for the selected company
        cur.execute("""SELECT c.company_name, a.year_reported
            , a.asset, a.sub_asset, a.asset_value, a.earnings_value
            FROM company c
            JOIN assets_earning_investments a ON c.company_id = a.company_id
            WHERE c.company_name = %s""", (selected_company,))
        asset_details = cur.fetchall()

    cur.close()
    conn.close()
    return render_template('assets.html', companies=companies, asset_details=asset_details, selected_company=selected_company)

@app.route('/housing', methods=['GET', 'POST'])
def housing():
    conn = db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    
    cur.execute("SELECT DISTINCT year_reported FROM housing_units_income")
    years = cur.fetchall()
    
    cur.execute("SELECT DISTINCT area FROM housing_units_income")
    areas = cur.fetchall()
    
    cur.execute("SELECT DISTINCT ownership FROM housing_units_income")
    ownerships = cur.fetchall()

    housing_data = []
    selected_year = None
    selected_area=None
    selected_ownership=None
    if request.method == 'POST':
        year = request.form.get('year')
        area = request.form.get('area')
        ownership = request.form.get('ownership')
        selected_year=year
        selected_area=area
        selected_ownership=ownership
        
        cur.execute("""
            SELECT c.company_name, h.year_reported, h.area, h.ownership, h.housing_units, h.income
            FROM company c
            JOIN housing_units_income h ON c.company_id = h.company_id
            WHERE h.year_reported = %s AND h.area = %s AND h.ownership = %s""", (year, area, ownership,))
        
        housing_data = cur.fetchall()

    cur.close()
    conn.close()
    return render_template('housing.html', years=years, areas=areas, ownerships=ownerships, housing_data=housing_data,selected_year=selected_year,selected_ownership=selected_ownership, selected_area=selected_area)



if __name__ == '__main__':
    app.run(debug=True, port=5001)
