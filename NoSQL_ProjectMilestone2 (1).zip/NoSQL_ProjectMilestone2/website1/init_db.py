import psycopg2
conn=psycopg2.connect(database="power_generation",host="localhost",user="postgres",password="postgres",,port="5432")
cur=conn.cursor()

